const _ = require('lodash');
const Promise = require('bluebird');
const AssistantV1 = require('ibm-watson/assistant/v1');

const { logger } = require('../utils/logger');

const sendMessageAsync = (apiKey, options) => {
    const { headers } = options;
    const assistant = new AssistantV1({
        iam_apikey: apiKey,
        version: '2018-07-10',
        url: process.env.WATSON_API_URL,
        headers,
    });

    return Promise.promisify(assistant.message, { context: assistant })(options);
};

const getResponse = async (workspaceName, watson, utterance, context) => {
    const {
        master, workspaces,
    } = watson;
    const updatedWorkspaceName = workspaceName.replace(/\s/g, '');
    const workspaceConfig = workspaces[updatedWorkspaceName] || workspaces[master];
    const { workspaceId, apiKey } = workspaceConfig;
    const options = {
        workspace_id: workspaceId,
        headers: {
            'X-Watson-Learning-Opt-Out': true,
            'X-Watson-Metadata': 'customer_id=abnamro_customer_id',
        },
        alternate_intents: true,
        input: { text: utterance },
        context,
    };

    logger.info(`Sending a request to watson with the following parameters :: ${JSON.stringify(options)}`);
    const response = await sendMessageAsync(apiKey, options);
    logger.info(`Received the response from watson :: ${JSON.stringify(response)}`);

    // check the output of the call to watson for any errors
    if (_.get(response, 'output.error', '').length > 0) {
        logger.error(`Watson assistant responded with :: error : ${response.output.error}`);
        throw new Error('Dialog error');
    }

    return response;
};

module.exports = { getResponse };
