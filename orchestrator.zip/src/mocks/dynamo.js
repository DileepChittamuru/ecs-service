module.exports.dynamoTestData = [
    {
        input: {
            id: '3f45ba210ad54616967e29db502e9218',
            workspace: 'Masterflow',
            context: {
                conversation_id: '04bf26e4-13f4-4050-ba03-2b5d63affb3b',
                system: {
                    dialog_request_counter: 2,
                    initialized: true,
                    dialog_stack: [
                        {
                            dialog_node: 'root',
                        },
                    ],
                    dialog_turn_counter: 2,
                },
            },
        },
        output: {
            id: '3f45ba210ad54616967e29db502e9218',
            context: {
                system: {
                    initialized: true,
                    dialog_stack: [
                        {
                            dialog_node: 'root',
                        },
                    ],
                    dialog_turn_counter: 2,
                    dialog_request_counter: 2,
                },
                conversation_id: '04bf26e4-13f4-4050-ba03-2b5d63affb3b',
            },
            workspace: 'Masterflow',
        },
    },
    {
        input: {
            id: 'e3c8d310-d915-11e8-894f-c51ebd401c1d',
            conversationId: '8cbe0a3ab8034713a10381ecbe67cc65',
            answers: [
                {
                    request: {
                        workspace: 'Masterflow',
                        utterance: '',
                        context: {},
                    },
                    response: {
                        intents: [],
                        entities: [],
                        input: {
                            text: '',
                        },
                        output: {
                            generic: [],
                            text: [],
                            nodes_visited: [],
                            internal: {
                                fallback: true,
                            },
                            warning: `No dialog node condition matched to true in the last dialog round - context.nodes_visited is empty. 
                                Falling back to the root node in the next round.`,
                            log_messages: [
                                {
                                    level: 'warn',
                                    msg: `No dialog node condition matched to true in the last dialog round - context.nodes_visited is empty. 
                                        Falling back to the root node in the next round.`,
                                },
                            ],
                        },
                        context: {
                            conversation_id: '5be5d9f1-fffc-402e-bebb-2959c758c69a',
                            system: {
                                initialized: true,
                                dialog_stack: [
                                    {
                                        dialog_node: 'root',
                                    },
                                ],
                                dialog_turn_counter: 1,
                                dialog_request_counter: 1,
                            },
                        },
                    },
                },
            ],
        },
        output: {
            id: 'e3c8d310-d915-11e8-894f-c51ebd401c1d',
            answers: [
                {
                    request: {
                        workspace: 'Masterflow',
                        context: {},
                    },
                    response: {
                        intents: [],
                        entities: [],
                        output: {
                            generic: [],
                            text: [],
                            nodes_visited: [],
                            internal: {
                                fallback: true,
                            },
                            warning: `No dialog node condition matched to true in the last dialog round - context.nodes_visited is empty. 
                                Falling back to the root node in the next round.`,
                            log_messages: [
                                {
                                    level: 'warn',
                                    msg: `No dialog node condition matched to true in the last dialog round - context.nodes_visited is empty. 
                                        Falling back to the root node in the next round.`,
                                },
                            ],
                        },
                        context: {
                            conversation_id: '5be5d9f1-fffc-402e-bebb-2959c758c69a',
                            system: {
                                initialized: true,
                                dialog_stack: [
                                    {
                                        dialog_node: 'root',
                                    },
                                ],
                                dialog_turn_counter: 1,
                                dialog_request_counter: 1,
                            },
                        },
                    },
                },
            ],
            conversationId: '8cbe0a3ab8034713a10381ecbe67cc65',
        },
    },
];
