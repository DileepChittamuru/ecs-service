module.exports = {
    watsonOneAnswer:
    [
        {
            request: {
                workspace: 'Masterflow',
                utterance: 'Hi',
                context: { counterRetry: 0 },
            },
            response: {
                intents: [
                    {
                        intent: 'Hello',
                        confidence: 1,
                    },
                ],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [
                        {
                            response_type: 'text',
                            text: 'Hello. How can I help you?',
                        },
                    ],
                    text: [
                        'Hello. How can I help you?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    system: {
                        initialized: true,
                        dialog_stack: [
                            {
                                dialog_node: 'Welcome',
                            },
                        ],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            },
        },
    ],
};
