module.exports = {
    getResponse: async (workspace) => {
        switch (workspace) {
        case 'Masterflow':
            return {
                request: {
                    workspace: 'Masterflow',
                    utterance: 'Hi',
                    context: {},
                },
                intents: [{
                    intent: 'Hello',
                    confidence: 1,
                }],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [{
                        response_type: 'text',
                        text: 'Hello. How can I help you?',
                    }],
                    text: [
                        'Hello. How can I help you?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    orc: {
                        passTo: 'iDeal',
                        ctx: {},
                    },
                    system: {
                        initialized: true,
                        dialog_stack: [{
                            dialog_node: 'Welcome',
                        }],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            };
        case 'iDeal':
            return {
                request: {
                    workspace: 'Masterflow',
                    utterance: 'Hi',
                    context: {},
                },
                intents: [{
                    intent: 'Hello',
                    confidence: 1,
                }],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [{
                        response_type: 'text',
                        text: 'Hello. How can I help you?',
                    }],
                    text: [
                        'Hello. How can I help you?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    orc: {
                        passTo: 'Masterflow',
                        ctx: {},
                    },
                    system: {
                        initialized: true,
                        dialog_stack: [{
                            dialog_node: 'Welcome',
                        }],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            };
        case 'ForeignTransfer':
            return {
                request: {
                    workspace: 'ForeignTransfer',
                    utterance: 'Hi',
                    context: {},
                },
                intents: [{
                    intent: 'Hello',
                    confidence: 1,
                }],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [{
                        response_type: 'text',
                        text: 'Hello. How can I help you with foreign transfers?',
                    }],
                    text: [
                        'Hello. How can I help you with foreign transfers?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    orc: {
                        passTo: 'ProcessingTimes',
                        ctx: {},
                    },
                    system: {
                        initialized: true,
                        dialog_stack: [{
                            dialog_node: 'Welcome',
                        }],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            };
        case 'ProcessingTimes':
            return {
                request: {
                    workspace: 'ProcessingTimes',
                    utterance: 'Hi',
                    context: {},
                },
                intents: [{
                    intent: 'Hello',
                    confidence: 1,
                }],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [{
                        response_type: 'text',
                        text: 'Hello. How can I help you with processing times?',
                    }],
                    text: [
                        'Hello. How can I help you with processing times?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    system: {
                        initialized: true,
                        dialog_stack: [{
                            dialog_node: 'Welcome',
                        }],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            };
        default:
            return {
                request: {
                    workspace: 'Masterflow',
                    utterance: 'Hi',
                    context: {},
                },
                intents: [{
                    intent: 'Hello',
                    confidence: 1,
                }],
                entities: [],
                input: {
                    text: 'Hi',
                },
                output: {
                    generic: [{
                        response_type: 'text',
                        text: 'Hello. How can I help you?',
                    }],
                    text: [
                        'Hello. How can I help you?',
                    ],
                    nodes_visited: [
                        'Welcome',
                    ],
                    log_messages: [],
                },
                context: {
                    conversation_id: '50ccb8f1-8a80-442b-ba52-1e0050a0271b',
                    system: {
                        initialized: true,
                        dialog_stack: [{
                            dialog_node: 'Welcome',
                        }],
                        dialog_turn_counter: 1,
                        dialog_request_counter: 1,
                        _node_output_map: {
                            Welcome: {
                                0: [
                                    0,
                                ],
                            },
                        },
                    },
                },
            };
        }
    },
};
