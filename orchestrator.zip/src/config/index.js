const getConfig = () => ({
    canDebug: process.env.ENVIRONMENT === 'dev'
        || process.env.ENVIRONMENT === 'test'
        || process.env.ENVIRONMENT === 'uat'
        || false,
});

module.exports = { getConfig };
