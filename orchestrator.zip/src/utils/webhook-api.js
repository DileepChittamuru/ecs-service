const _ = require('lodash');
const rp = require('request-promise');
const { logger } = require('./logger');

const webhookApi = async (webhook, response) => {
    logger.info('Webhook Parameterstore Details:::', webhook);
    const options = {
        url: webhook.url,
        method: 'POST',
        timeout: 10000,
        body: response,
        json: true,
    };
    if (webhook.basicAuth) {
        const { username, password } = webhook.basicAuth;
        options.auth = {
            username,
            password,
        };
    }
    if (webhook.headers) {
        options.headers = webhook.headers;
    }
    try {
        const externalResponse = await rp(options);
        logger.info('Webhook response:::', externalResponse);
        return externalResponse;
    } catch (e) {
        if (_.get(e, 'cause.code', false)) {
            throw e.cause.code;
        } else {
            throw e.statusCode;
        }
    }
};

module.exports = {
    webhookApi,
};
