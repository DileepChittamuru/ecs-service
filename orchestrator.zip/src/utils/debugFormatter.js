const _ = require('lodash');
const flatten = require('flat');
const { logger } = require('./logger');


const getDebugResponse = (answers) => {
    try {
        return _.chain(answers)
            .map((answer) => {
                const { request, response } = answer;

                /*
                 * If the debug is ON, enter god mode and show enriched chat.
                 * This code is used to show diagnostic logs inside the chat.
                 * It prepends the query, and appends the response.
                 */
                const preObj = {
                    workspace: request.workspace,
                    utterance: request.utterance,
                    context: _.omit(request.context, 'system'),
                };
                const postObj = {
                    intents: _.get(response, 'intents'),
                    nodes_visited: _.get(response, 'output.nodes_visited'),
                    dialog_stack: _.get(response, 'context.system.dialog_stack'),
                    orc: _.get(response, 'context.orc'),
                };
                const [pre, post] = _.chain([preObj, postObj])
                    .map(flatten)
                    .map(obj => _.map(obj, (val, key) => `${key} => ${val}`)
                        .join('\n'))
                    .value();

                return ['-----PRE-----', pre, '-----POST-----', post, '-----ACTUAL-----'];
            })
            .flattenDeep()
            .filter(message => message !== '')
            .value();
    } catch (error) {
        logger.error('Encountered error when debugging orchestrator response');
        logger.error(error);
        throw error;
    }
};

const responseOutput = debugOutput => _.map(debugOutput, answer => ({
    text: answer,
    response_type: 'text',
}));

const getSwagFormat = (debugOutput, answers = null) => {
    const debugFormat = responseOutput(debugOutput);

    try {
        const answerFormatSwag = _.chain(answers)
            .filter(answer => !_.isEmpty(answer.response.output.text))
            .map((answer) => {
                const parsedText = JSON.parse(answer.response.output.text[0]);
                return parsedText.default;
            })
            .flatten()
            .value();

        return [JSON.stringify({
            default: [...debugFormat, ...answerFormatSwag],
        })];
    } catch (err) {
        logger.info(`Input is not swagger format ${err}`);
        return 'Answer from Watson not in SWAG format';
    }
};

const getRawFormat = (debugOutput, answers = null) => {
    const debugGeneric = responseOutput(debugOutput);
    const debugText = _.map(debugOutput, answer => answer);

    const answerGeneric = _.chain(answers)
        .filter(answer => !_.isEmpty(answer.response.output.generic))
        .map(answer => answer.response.output.generic)
        .flatten()
        .value();

    const answerText = _.chain(answers)
        .filter(answer => !_.isEmpty(answer.response.output.text))
        .map(answer => answer.response.output.text)
        .flatten()
        .value();

    return [{
        response: {
            output: {
                generic: [...debugGeneric, ...answerGeneric],
                text: [...debugText, ...answerText],
            },
        },
    }];
};

module.exports = { getDebugResponse, getSwagFormat, getRawFormat };
