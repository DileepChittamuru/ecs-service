const { createLogger, format, transports } = require('winston');

const {
    combine,
    align,
    simple,
} = format;

const textLogFormat = combine(
    align(),
    simple(),
);

const consoleTransport = new transports.Console();

const options = {
    format: textLogFormat,
    transports: [consoleTransport],
    exitOnError: false,
};

const silent = !!(process.env.TEST || false);

const logger = createLogger({ ...options, silent, level: process.env.LOG_LEVEL || 'info' });

module.exports = { logger };
