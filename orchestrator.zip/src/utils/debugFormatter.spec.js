const {
    getSwagFormat, getRawFormat, getDebugResponse,
} = require('./debugFormatter');
const { watsonOneAnswer } = require('../mocks/watson');

describe('debug formatter', () => {
    describe('format the result from orchestrator for to PRE, POST and ACTUAL', () => {
        it('should respond with array of debug messages', () => {
            const message = getDebugResponse(watsonOneAnswer);

            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';
            const post = 'intents.0.intent => Hello\nintents.0.confidence => 1'
                + '\nnodes_visited.0 => Welcome\ndialog_stack.0.dialog_node => Welcome\norc => undefined';

            const output = ['-----PRE-----', pre, '-----POST-----', post, '-----ACTUAL-----'];

            expect(message).toEqual(output);
        });
    });

    describe('getSwagFormat', () => {
        it('should create Swag format', () => {
            const debugOuput = ['God mode :: ON'];

            expect(getSwagFormat(debugOuput, null)).toEqual([JSON.stringify(
                {
                    default: [{
                        text: 'God mode :: ON',
                        response_type: 'text',
                    }],
                },
            )]);
        });

        it('should create swag FORMAT and empty answer is ignored', () => {
            const debugOuput = ['God mode :: ON'];

            const answer = [{
                response: {
                    output: {
                        generic: [],
                        text: [],
                    },
                },
            }];

            expect(getSwagFormat(debugOuput, answer))
                .toEqual([JSON.stringify(
                    {
                        default: [{
                            text: 'God mode :: ON',
                            response_type: 'text',
                        }],
                    },
                )]);
        });

        it('should set debug values and add answer value from watsonOneAnswer', () => {
            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';
            const debugOutput = ['--pre--', pre];

            const answer = [
                {
                    response: {
                        output: {
                            generic: [
                                {
                                    response_type: 'text',
                                    text: '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                                },
                            ],
                            text: [
                                '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                            ],
                        },
                    },
                },
            ];

            expect(getSwagFormat(debugOutput, answer))
                .toEqual([JSON.stringify(
                    {
                        default: [
                            {
                                text: '--pre--',
                                response_type: 'text',
                            },
                            {
                                text: 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                                response_type: 'text',
                            }, {
                                text: 'Hallo, ik ben chatbot Anna, uw online assistente.',
                                response_type: 'text',
                            }],
                    },
                )]);
        });

        it('should return error with inccorect SWAG format when answer is not written in swag format', () => {
            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';
            const debugOutput = ['--pre--', pre];

            const answer = [
                {
                    response: {
                        output: {
                            text: [
                                'message',
                            ],
                        },
                    },
                },
            ];

            expect(getSwagFormat(debugOutput, answer))
                .toEqual('Answer from Watson not in SWAG format');
        });
    });

    describe('getRawFormat ', () => {
        it('should format debugOut without actual answers from watson', () => {
            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';
            const debugOutput = ['--pre--', pre];

            const output = [{
                response: {
                    output: {
                        generic: [
                            {
                                response_type: 'text',
                                text: '--pre--',
                            },
                            {
                                response_type: 'text',
                                text: 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                            },
                        ],
                        text: [
                            '--pre--', 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                        ],
                    },
                },
            }];

            expect(getRawFormat(debugOutput, null))
                .toEqual(output);
        });

        it('should format debugOut without actual answers from watson without NULL', () => {
            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';

            const debugOutput = ['--pre--', pre];
            const answer = [
                {
                    response: {
                        output: {
                            generic: [],
                            text: [],
                        },
                    },
                },
            ];

            const output = [{
                response: {
                    output: {
                        generic: [
                            {
                                response_type: 'text',
                                text: '--pre--',
                            },
                            {
                                response_type: 'text',
                                text: 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                            },
                        ],
                        text: [
                            '--pre--', 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                        ],
                    },
                },
            }];

            expect(getRawFormat(debugOutput, answer))
                .toEqual(output);
        });

        it('should return debugOutput responses with actual answers', () => {
            const pre = 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0';
            const debugOutput = ['--pre--', pre];

            const answer = [
                {
                    response: {
                        output: {
                            generic: [
                                {
                                    response_type: 'text',
                                    text: '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                                },
                            ],
                            text: [
                                '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                            ],
                        },
                    },
                },
            ];

            const output = [{
                response: {
                    output: {
                        generic: [
                            {
                                response_type: 'text',
                                text: '--pre--',
                            },
                            {
                                response_type: 'text',
                                text: 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                            },
                            {
                                text: '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                                response_type: 'text',
                            },
                        ],
                        text: [
                            '--pre--', 'workspace => Masterflow\nutterance => Hi\ncontext.counterRetry => 0',
                            '{"default":[{"text":"Hallo, ik ben chatbot Anna, uw online assistente.","response_type":"text"}]}',
                        ],
                    },
                },
            }];

            expect(getRawFormat(debugOutput, answer))
                .toEqual(output);
        });
    });
});
