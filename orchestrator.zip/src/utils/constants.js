module.exports = {
    MAX_CIRCULAR_DEPENDENCY_ALLOWED: 5,
};
