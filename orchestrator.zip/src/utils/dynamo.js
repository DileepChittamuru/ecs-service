const _ = require('lodash');
const AWS = require('aws-sdk');
const { sanitizeDynamo } = require('./formatter');

const docClient = new AWS.DynamoDB.DocumentClient();

module.exports = (tableName, botId) => ({

    put(data, id, sanitize = true) {
        const item = _.assign({}, data, { id, botId });
        const params = {
            Item: sanitize ? sanitizeDynamo(item) : item,
            TableName: tableName,
        };
        return docClient.put(params).promise();
    },
    get(id) {
        const params = {
            Key: { id, botId },
            TableName: tableName,
        };
        return docClient.get(params).promise();
    },
    update(id, attributes) {
        const ExpressionAttributeValues = {};
        let UpdateExpression = '';
        const expressions = [];

        Object.keys(attributes).forEach((i) => {
            expressions.push(`${i} = :${i}`);
            ExpressionAttributeValues[`:${i}`] = attributes[i];
        });
        UpdateExpression = `set ${expressions.join(',')}`;

        const params = {
            Key: { id, botId },
            TableName: tableName,
            UpdateExpression,
            ExpressionAttributeValues,
        };

        return docClient.update(params).promise();
    },
});
