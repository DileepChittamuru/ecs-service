const _ = require('lodash');
const flatten = require('flat');
const { unflatten } = require('flat');

const { logger } = require('./logger');

const sanitizeDynamo = (obj) => {
    const flattenedObj = flatten(obj);
    const sanitizedFlatObj = _.chain(flattenedObj).reduce((acc, val, key) => {
        if (val !== '') { return _.set(acc, key, val); }
        return acc;
    }, {}).value();
    return unflatten(sanitizedFlatObj);
};

const getOrchestratorResponse = (answers) => {
    try {
        const extractedAnswers = _.chain(answers)
            .map((answer) => {
                const { response } = answer;
                return response.output.text;
            })
            .flattenDeep()
            .filter(message => message !== '')
            .value();
        return extractedAnswers;
    } catch (error) {
        logger.error('Encountered error when sanitizing orchestrator response');
        logger.error(error);
        throw error;
    }
};

module.exports = { sanitizeDynamo, getOrchestratorResponse };
