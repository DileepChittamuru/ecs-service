const { dynamoTestData } = require('../mocks/dynamo');
const { sanitizeDynamo, getOrchestratorResponse } = require('./formatter');
const { watsonOneAnswer } = require('../mocks/watson');

describe('sanitize', () => {
    describe('sanitize the data (strip out blank values) for dynamoDB', () => {
        it('should not strip non null key-value pairs from the object', () => {
            expect(sanitizeDynamo(dynamoTestData[0].input))
                .toEqual(dynamoTestData[0].output);
        });

        it('should strip non null key-value pairs from the object', () => {
            expect(sanitizeDynamo(dynamoTestData[1].input))
                .toEqual(dynamoTestData[1].output);
        });
    });

    describe('format the result from orchestrator for its consumer', () => {
        it('should respond with an array of strings', () => {
            expect(getOrchestratorResponse(watsonOneAnswer))
                .toEqual(watsonOneAnswer[0].response.output.text);
        });

        it('should respond with an empty array when no answers provided', () => {
            const expectedOutput = [];
            expect(getOrchestratorResponse([])).toEqual(expectedOutput);
            expect(getOrchestratorResponse(null)).toEqual(expectedOutput);
            expect(getOrchestratorResponse(undefined)).toEqual(expectedOutput);
            expect(getOrchestratorResponse(new Error())).toEqual(expectedOutput);
        });

        it('should throw an Error when triggered with an invalid input', () => {
            const expectedError = new TypeError('Cannot read property \'output\' of undefined');
            expect(() => getOrchestratorResponse([1234])).toThrow(expectedError);
        });
    });
});
