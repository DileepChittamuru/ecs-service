const _ = require('lodash');
const rp = require('request-promise');

const { logger } = require('./logger');

const root = 'appConfigV2';

const getParameters = async (botId, environment) => {
    const path = `/${root}/bots/${botId}/${environment}`;
    try {
        // retrieve parameters
        const options = {
            url: `${process.env.PARAMETER_STORE_BASE_URL}/paramService/getParams`,
            qs: { path },
            json: true,
        };
        const parameters = await rp(options);

        logger.info(`Parameter Store :: retrieved parameters :: ${JSON.stringify(parameters)}`);

        // transform the configuration structure of the retrieved parameters to a name - value map
        const { configuration } = parameters;
        const nlp = _(configuration.nlp)
            .keyBy('provider')
            .reduce((acc, nlpConfig) => {
                const workspaces = _.keyBy(nlpConfig.workspaces, 'workspaceName');
                acc[nlpConfig.provider] = { ...nlpConfig, workspaces };
                return acc;
            }, {});
        const log = _.keyBy(configuration.log, 'provider');
        const { webhook } = configuration;
        return { ...parameters, configuration: { nlp, log, webhook } };
    } catch (error) {
        logger.error(`Parameter Store Error :: Failed to retrieve parameters for path: ${path}`);
        logger.error(error);
        throw error;
    }
};

module.exports = {
    getParameters,
};
