const express = require('express');

const { logger } = require('../utils/logger');
const { router } = require('./router');

const app = express();
const port = 8080;

/*
Attach the router so that root path of the service routes become agnostic of the path-pattern specified within the ALB
e.g. - endpoint for ping is <url>/<any-alb-path-pattern>/ping
*/
app.use(/\/[\w-]+/, router);

app.listen(port, () => logger.info(`Listening on port: ${port}`));
