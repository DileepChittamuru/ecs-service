/* global expectAsync */
const proxyquire = require('proxyquire');

const orchestrator = proxyquire('./orchestrator', {
    '../nlp/watson': require('../mocks/watsonCircularDependency'),
});

describe('getResponse', () => {
    describe('check for circular dependency', () => {
        it('normal flow without circular dependency', async () => {
            const watsonResponse = await orchestrator.getResponse('Retail-Payments');
            expect(watsonResponse.answers[0].response.output.generic[0].text).toEqual('Hello. How can I help you?');
        });
        it('allows for a well defined passTo functionality to be triggered infinite amount of times', async () => {
            let watsonResponse;
            for (let i = 0; i < 10; i++) { // eslint-disable-line
                watsonResponse = await orchestrator.getResponse('ForeignTransfer'); // eslint-disable-line
            }
            expect(watsonResponse.answers[0].response.output.generic[0].text).toEqual('Hello. How can I help you with foreign transfers?');
            expect(watsonResponse.answers[1].response.output.generic[0].text).toEqual('Hello. How can I help you with processing times?');
        });
        it('should throw error when there is circular dependency in passTo', () => {
            expectAsync(orchestrator.getResponse('Masterflow')).toBeRejectedWith(new Error('Circular dependency detected'));
        });
    });
});
