const _ = require('lodash');
const bodyParser = require('body-parser');
const express = require('express');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');

const Dynamo = require('../utils/dynamo');
const { getConfig } = require('../config');
const { getParameters } = require('../utils/parameter-store');
const { getResponse } = require('../orchestrator/orchestrator');
const { logger } = require('../utils/logger');
const { getDebugResponse, getSwagFormat, getRawFormat } = require('../utils/debugFormatter');
const { getOrchestratorResponse } = require('../utils/formatter');

const swaggerJson = YAML.load(`${__dirname}/../../api-specification-web.yml`);
const router = express.Router();

router.use(bodyParser.json());

router.get('/ping', (req, res) => {
    res.send('Orchestrator is alive!');
});

router.get('/swagger/raw', (req, res) => {
    logger.info('orchestrator :: /orchestrator-v3/swagger/raw');
    res.set('Content-Type', 'application/json');
    res.send(swaggerJson);
});

router.use('/swagger', swaggerUi.serve, swaggerUi.setup(swaggerJson));

router.post('/:botId/:environment/getResponse', async (req, res) => {
    try {
        logger.info(`Orchestrator hit from :: ${JSON.stringify(req.params)}`);
        const { botId, environment } = req.params;
        logger.info(`Orchestrator hit with :: ${JSON.stringify(req.body)}`);
        const { body: payload } = req;
        const { configuration } = await getParameters(botId, environment);
        const config = await getConfig();
        const { canDebug } = config;
        const { watson } = configuration.nlp;
        const { webhook } = configuration;
        const { master } = watson;
        const conversationId = payload.conversationId.toString();
        const {
            message, context: requestContext, event: requestEvent,
        } = payload;
        logger.info(`Orchestrator received context :: ${JSON.stringify(requestContext)}`);
        logger.info(`Orchestrator received request event :: ${JSON.stringify(requestEvent)}`);
        const { text: utterance } = message;

        const { CONTEXT_TABLE } = process.env;
        logger.info(`About to query the table :: ${CONTEXT_TABLE} for bot :: ${botId} with :: conversationId :: ${conversationId}`);
        const { Item } = await Dynamo(CONTEXT_TABLE, botId).get(conversationId);
        logger.info(`Retrieved Item from dynamo for id :: ${conversationId}`, Item);

        const savedWorkspace = _.get(Item, 'workspace');
        const savedContext = _.get(Item, 'context');
        let debug = canDebug && _.get(Item, 'debug', false);

        // to start debug mode
        if (canDebug && utterance === 'debug') {
            // toggle debug flag
            debug = !debug;
            logger.info(`Debug mode set to :: ${debug}`);

            await Dynamo(CONTEXT_TABLE, botId).put({ ...Item, id: conversationId, debug }, conversationId);
            logger.info(`Stored the conversation into Dynamo under the conversation id :: ${conversationId}`);

            const normalized = getSwagFormat([`God mode :: ${debug ? 'ON' : 'OFF'}`]);
            const raw = getRawFormat([`God mode :: ${debug ? 'ON' : 'OFF'}`]);
            const debugToggleResponse = JSON.stringify({ normalized, raw });
            logger.info(`Toggling the debug :: ${debugToggleResponse}`);

            // respond with the payload and exit
            res.send(debugToggleResponse);
            return;
        }

        let initialWorkspace = savedWorkspace;
        let initialContext = { ...savedContext, ...requestContext };
        if (!utterance) {
            logger.info('Conversation started, reset all contexts');
            initialWorkspace = master;
            initialContext = { ...requestContext };
        }
        if (!initialWorkspace) {
            initialWorkspace = master;
        }
        const {
            answers, context, workspace,
        } = await getResponse(initialWorkspace, utterance, initialContext, watson, webhook);

        logger.info('Answers :::', answers);
        logger.info('FinalContext :::', context);
        logger.info(`FinalWorkspace ::: ${workspace}`);

        const contextItem = {
            ...Item, id: conversationId, context, workspace,
        };
        logger.info('Saving context state ::: ', contextItem);
        await Dynamo(CONTEXT_TABLE, botId).put(contextItem, conversationId);

        // create responses for debug mode
        if (debug) {
            const debugOutput = getDebugResponse(answers);
            const normalized = getSwagFormat(debugOutput, answers);
            const raw = getRawFormat(debugOutput, answers);

            logger.info(`Swag Format ::  ${JSON.stringify(normalized)}`);
            logger.info(`Raw Format ::  ${JSON.stringify(raw)}`);
            const finalDebugResponse = JSON.stringify({ normalized, raw });
            logger.info(`Final debug response ::  ${finalDebugResponse}`);
            res.send(finalDebugResponse);
            return;
        }

        // transform the resulting answers into an array of strings
        const normalized = getOrchestratorResponse(answers);

        // provide the consumer with both normalized and raw watson responses
        res.send(JSON.stringify({
            normalized,
            raw: answers,
        }));
    } catch (error) {
        logger.error(`Orchestrator :: Error at getResponse ${error}`, error);
        res.status(500).send('Internal server error');
    }
});

module.exports = { router };
