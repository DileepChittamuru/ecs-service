const _ = require('lodash');
const { logger } = require('../utils/logger');
const watsonApi = require('../nlp/watson');
const { webhookApi } = require('../utils/webhook-api');
const constants = require('../utils/constants');

async function getResponse(
    workspace,
    utterance = '',
    context = {},
    watson = {},
    webhook,
    answers = [],
    workspaceToCallCountMap = {},
) {
    try {
        logger.info(`Queried ${workspace} workspace with ${utterance}`);
        logger.info('Context Supplied :::', context);
        const request = { workspace, utterance, context };
        // get response from watson
        let response = await watsonApi.getResponse(workspace, watson, utterance, context);
        logger.info('Response returned :::', response);
        const external = _.get(response, 'context.orc.external', false);
        if (external && webhook) {
            try {
                response = await webhookApi(webhook, response);
            } catch (e) {
                logger.warn(`Webhook response failed with status ${e}, Watson response will be used`);
            }
            // Removes external as it has been handled
            _.unset(response, 'context.orc.external');
        }

        const { input, context: outputContext } = response;
        logger.info('Context returned :::', outputContext);

        // keep collecting intents, entities and output for each API response
        const newAnswers = [...answers, { request, response }];

        // extract orchestrator variables(passTo, sendThenSwitch & ctx) from outputContext
        const { passTo, sendThenSwitch, ctx } = _.get(outputContext, 'orc', {});

        /*
         * set newWorkspace to passTo or sendThenSwitch or workspace
         * (if any is present, in that order)
         */
        const newWorkspace = passTo || sendThenSwitch || workspace;

        // if workspace was switched then use ctx for new context
        const newContext = newWorkspace !== workspace ? ctx : outputContext;
        const newWorkspaceToCallCountMap = { ...workspaceToCallCountMap };
        if (passTo) {
            // recursively call the API till passTo exists
            const workspaceCallCount = newWorkspaceToCallCountMap[newWorkspace] || 0;
            newWorkspaceToCallCountMap[newWorkspace] = workspaceCallCount + 1;
            // check for circular dependency between two workspaces introduced by the copywriters
            if (newWorkspaceToCallCountMap[newWorkspace] > constants.MAX_CIRCULAR_DEPENDENCY_ALLOWED) {
                throw Error('Circular dependency detected');
            }
            // check for original input text to avoid passing auto corrected utterance.
            const originalUtterance = input.original_text || input.text;
            return getResponse(newWorkspace, originalUtterance, newContext, watson, webhook, newAnswers, newWorkspaceToCallCountMap);
        }
        return {
            answers: newAnswers,
            context: newContext,
            workspace: newWorkspace,
        };
    } catch (error) {
        logger.error(`Orchestrator Conversation Orchestrator :: Watson Error :: ${error}`, error);
        // in case of error, return answer until previous step
        return {
            answers, context, workspace,
        };
    }
}

module.exports = { getResponse };
