# Orchestrator service
The purpose of this microservice is to orchestrate the chat via custom logic over the nlp instance. The core of the service can be found within the `orchestrator.js` source code file.

The business logic specified within the `orchestrator.js` file is integrated within our platform as can be seen in `orchestrator/index.js`.

# Sample messages
Here we provide some sample messages for testing purposes

## Happy path:

You start at the beginning of the chat and end up at the master workspace after being provided an answer to a question within a slave workspace.

Make sure to clear the orchestrator dynamo db when running tests.
```
curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": ""},"conversationId": "666022", "event": {"some": "small event"}, "context": {"isLiveChatOpen": true, "isClosedDomain": false}}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Ik snap het"},"conversationId": "666022"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Hoe duur is een overboeking naar Slowakije"},"conversationId": "666022"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Nee"},"conversationId": "666022"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Ja"},"conversationId": "666022"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Ja"},"conversationId": "666022"}'
```

## No Context - Watson error

Responds with an empty array to the question and logs the watson error.
```
curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Hoe duur is een overboeking naar Slowakije"},"conversationId": "666012"}'
```

## Multitenant check

Tenant 1 - get to the menu button section fo conversation

```
curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Authorization: Basic MmFhYTBlZDgtYjJmMS00MzdmLWFkOTYtNjU4ODAwZjdmNjE0OlpxRlZtR0cwRnhwdQ==' \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": ""},"conversationId": "666017", "event": {"some": "small event"}, "context": {"isLiveChatOpen": true, "isClosedDomain": false}}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/028a3596/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Ik snap het"},"conversationId": "666017"}'
```

Tenant 2 - same chatbot structure, same conversation id nevertheless cannot proceed with conversation since the context is not set. Orchestrator responds with empty array

```
curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/666/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Hoe duur is een overboeking naar Slowakije"},"conversationId": "666017"}'
```

Tenant 3 - different chatbot structure + different 

```
curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/IgorsBot/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Hi"},"conversationId": "99017"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/IgorsBot/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Im fine"},"conversationId": "99017"}'

curl -X POST \
  https://6l8azhnba5.execute-api.eu-west-1.amazonaws.com/Prod/IgorsBot/dev/getResponse \
  -H 'Content-Type: application/json' \
  -d '{"message": {"text": "Yup"},"conversationId": "99017"}'
```
